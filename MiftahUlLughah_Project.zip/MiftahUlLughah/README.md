# Miftah-ul-Lughah Android app

Offline-first Android Studio project for a personal Arabic vocabulary dictionary.

## Features
- Arabic alphabet gallery with per-letter word counts
- Selecting a letter replaces the gallery area with that letter's saved words
- Back button returns to the alphabet gallery
- Add, edit, delete, search, and alphabetical sorting
- Optional Urdu meaning, root, باب, and personal note
- Local persistent storage using Android SharedPreferences
- JSON backup and restore using Android document picker

## Build APK
1. Open this folder in Android Studio (Hedgehog or newer recommended).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will produce the debug APK under `app/build/outputs/apk/debug/`.

Package: `com.miftahullughah.app`
Minimum Android: 6.0 (API 23)
