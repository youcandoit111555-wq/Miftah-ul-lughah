package com.miftahullughah.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    private final String[] letters = {"ا","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ک","ل","م","ن","ہ","و","ی"};
    private final ArrayList<Word> words = new ArrayList<>();
    private LinearLayout root, content, header;
    private String selectedLetter = "";
    private boolean searchMode = false;
    private EditText searchInput;
    private static final int EXPORT_REQ = 41, IMPORT_REQ = 42;
    private final int green = 0xFF234A3A, cream = 0xFFF6F2E9, muted = 0xFF817866;

    static class Word {
        String word, meaning, root, bab, note;
        Word(String w, String m, String r, String b, String n) { word=w; meaning=m; root=r; bab=b; note=n; }
        JSONObject json() throws JSONException { JSONObject o=new JSONObject(); o.put("word",word); o.put("meaning",meaning); o.put("root",root); o.put("bab",bab); o.put("note",note); return o; }
    }

    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(0xFF18382D); getWindow().setNavigationBarColor(0xFF18382D); load(); showHome(); }

    private void load() {
        try { JSONArray a=new JSONArray(getPreferences(0).getString("words","[]")); for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i); words.add(new Word(o.optString("word"),o.optString("meaning"),o.optString("root"),o.optString("bab"),o.optString("note")));} }
        catch(Exception ignored) {}
    }
    private void save() {
        JSONArray a=new JSONArray(); try { for(Word w:words)a.put(w.json()); } catch(Exception ignored) {}
        getPreferences(0).edit().putString("words",a.toString()).apply();
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(0xFFFFFFFF);b.setAllCaps(false);b.setTextSize(14);b.setBackground(bg(green,12));return b;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void base(String subtitle){
        root=vertical();root.setBackgroundColor(cream);setContentView(root);
        header=vertical();header.setPadding(dp(20),dp(18),dp(20),dp(16));header.setBackground(bg(green,0));
        TextView title=text("مِفْتَاحُ اللُّغَة",26,0xFFF5EBD5,true); title.setGravity(Gravity.CENTER);header.addView(title);
        TextView sub=text("ARABIC PERSONAL DICTIONARY",10,0xFFD9C99F,true);sub.setGravity(Gravity.CENTER);header.addView(sub);
        root.addView(header,new LinearLayout.LayoutParams(-1,-2));
        ScrollView scroll=new ScrollView(this);content=vertical();content.setPadding(dp(16),dp(14),dp(16),dp(24));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(subtitle!=null){TextView h=text(subtitle,19,green,true);h.setGravity(Gravity.RIGHT);content.addView(h);}
    }
    private void showHome(){selectedLetter="";searchMode=false;base("اپنی عربی لغت");
        LinearLayout actions=horizontal(); Button add=button("＋ نیا لفظ شامل کریں"); actions.addView(add,new LinearLayout.LayoutParams(0,dp(48),1)); add.setOnClickListener(v->editDialog(-1));
        Button backup=button("بیک اَپ"); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(104),dp(48));bp.setMargins(dp(8),0,0,0);actions.addView(backup,bp);backup.setOnClickListener(v->exportBackup());content.addView(actions);
        LinearLayout restoreRow=horizontal(); Button restore=button("بیک اَپ بحال کریں");restoreRow.addView(restore);restore.setOnClickListener(v->importBackup());content.addView(restoreRow);
        EditText q=new EditText(this);q.setSingleLine(true);q.setTextSize(16);q.setHint("عربی لفظ تلاش کریں");q.setGravity(Gravity.RIGHT);q.setBackground(bg(0xFFFFFFFF,12));q.setPadding(dp(12),0,dp(12),0);LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(-1,dp(50));qp.setMargins(0,dp(14),0,dp(8));content.addView(q,qp);
        Button search=button("تلاش کریں");content.addView(search,new LinearLayout.LayoutParams(-1,dp(46)));search.setOnClickListener(v->{((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(q.getWindowToken(),0);showSearch(q.getText().toString().trim());});
        TextView hint=text("حروف کی گیلری — کسی حرف پر کلک کریں",14,muted,true);hint.setGravity(Gravity.RIGHT);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(42));hp.topMargin=dp(12);content.addView(hint,hp);
        showGalleryGrid(content);
    }
    private int count(String l){int n=0;for(Word w:words)if(first(w.word).equals(l))n++;return n;}
    private String first(String s){if(s==null||s.trim().isEmpty())return "";String x=s.trim(); if(x.startsWith("أ")||x.startsWith("إ")||x.startsWith("آ"))return "ا";return x.substring(0,1);}
    private void showGalleryGrid(LinearLayout target){
        for(int start=0;start<letters.length;start+=4){LinearLayout row=horizontal();for(int j=start;j<Math.min(start+4,letters.length);j++){final String l=letters[j];LinearLayout tile=vertical();tile.setGravity(Gravity.CENTER);tile.setBackground(bg(0xFFFFFFFF,12));tile.setPadding(dp(4),dp(8),dp(4),dp(6));TextView ch=text(l,28,green,true);ch.setGravity(Gravity.CENTER);tile.addView(ch);TextView c=text(count(l)+" الفاظ",10,muted,false);c.setGravity(Gravity.CENTER);tile.addView(c);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(76),1);p.setMargins(dp(3),dp(3),dp(3),dp(3));row.addView(tile,p);tile.setOnClickListener(v->showLetter(l));}target.addView(row);}
    }
    private void showLetter(String l){selectedLetter=l;searchMode=false;showWordScreen("حرف  "+l,filter(l));}
    private ArrayList<Word> filter(String l){ArrayList<Word> a=new ArrayList<>();for(Word w:words)if(first(w.word).equals(l))a.add(w);sort(a);return a;}
    private void sort(ArrayList<Word> a){Collections.sort(a,(x,y)->x.word.compareToIgnoreCase(y.word));}
    private void showSearch(String q){searchMode=true;selectedLetter="";ArrayList<Word>a=new ArrayList<>();for(Word w:words)if(w.word.contains(q)||w.meaning.contains(q)||w.root.contains(q))a.add(w);sort(a);showWordScreen("تلاش کے نتائج",a);}
    private void showWordScreen(String title,ArrayList<Word> list){base(title);
        Button back=button("← واپس حروف کی گیلری");content.addView(back,new LinearLayout.LayoutParams(-1,dp(46)));back.setOnClickListener(v->showHome());
        TextView count=text(list.size()+" محفوظ الفاظ",13,muted,true);count.setGravity(Gravity.RIGHT);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(38));content.addView(count,cp);
        if(list.isEmpty()){TextView empty=text("ابھی اس حصے میں کوئی لفظ محفوظ نہیں۔",15,muted,false);empty.setGravity(Gravity.CENTER);content.addView(empty,new LinearLayout.LayoutParams(-1,dp(100)));}
        for(Word w:list){int idx=words.indexOf(w);LinearLayout card=vertical();card.setPadding(dp(14),dp(10),dp(14),dp(10));card.setBackground(bg(0xFFFFFFFF,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(5));content.addView(card,p);
            TextView word=text(w.word,24,green,true);word.setGravity(Gravity.RIGHT);card.addView(word);
            if(!w.meaning.isEmpty())addDetail(card,"معنی: "+w.meaning);if(!w.root.isEmpty())addDetail(card,"مادہ: "+w.root);if(!w.bab.isEmpty())addDetail(card,"باب: "+w.bab);if(!w.note.isEmpty())addDetail(card,"نوٹ: "+w.note);
            LinearLayout row=horizontal();Button edit=button("ترمیم");Button del=button("حذف");LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,dp(40),1);ep.setMargins(0,dp(8),dp(5),0);row.addView(edit,ep);LinearLayout.LayoutParams dp1=new LinearLayout.LayoutParams(0,dp(40),1);dp1.setMargins(dp(5),dp(8),0,0);row.addView(del,dp1);card.addView(row);edit.setOnClickListener(v->editDialog(idx));del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("کیا آپ یہ لفظ حذف کرنا چاہتے ہیں؟").setNegativeButton("نہیں",null).setPositiveButton("حذف",(d,x)->{words.remove(w);save();if(searchMode)showSearch("");else showLetter(selectedLetter);}).show());
        }
        Button add=button("＋ نیا لفظ شامل کریں");LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(48));ap.topMargin=dp(12);content.addView(add,ap);add.setOnClickListener(v->editDialog(-1));
    }
    private void addDetail(LinearLayout c,String s){TextView t=text(s,14,0xFF555047,false);t.setGravity(Gravity.RIGHT);c.addView(t);}
    private void editDialog(int index){Word old=index>=0?words.get(index):null;LinearLayout form=vertical();form.setPadding(dp(8),dp(4),dp(8),dp(4));EditText word=field("عربی لفظ *",old==null?"":old.word);EditText meaning=field("اردو معنی",old==null?"":old.meaning);EditText rootf=field("مادہ / روٹ",old==null?"":old.root);EditText bab=field("باب",old==null?"":old.bab);EditText note=field("مثال یا ذاتی نوٹ",old==null?"":old.note);form.addView(word);form.addView(meaning);form.addView(rootf);form.addView(bab);form.addView(note);
        new AlertDialog.Builder(this).setTitle(old==null?"نیا لفظ شامل کریں":"لفظ میں ترمیم").setView(form).setNegativeButton("منسوخ",null).setPositiveButton("محفوظ کریں",(d,x)->{String w=word.getText().toString().trim();if(w.isEmpty()){Toast.makeText(this,"عربی لفظ درج کریں",Toast.LENGTH_SHORT).show();return;}Word nw=new Word(w,meaning.getText().toString().trim(),rootf.getText().toString().trim(),bab.getText().toString().trim(),note.getText().toString().trim());if(index>=0)words.set(index,nw);else words.add(nw);save();if(selectedLetter.length()>0)showLetter(selectedLetter);else if(searchMode)showSearch("");else showHome();}).show();
    }
    private EditText field(String hint,String value){EditText e=new EditText(this);e.setSingleLine(false);e.setTextSize(16);e.setHint(hint);e.setText(value);e.setGravity(Gravity.RIGHT);e.setPadding(dp(8),dp(4),dp(8),dp(4));return e;}
    private void exportBackup(){try{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"Miftah-ul-Lughah-Backup.json");startActivityForResult(i,EXPORT_REQ);}catch(Exception e){Toast.makeText(this,"بیک اَپ شروع نہیں ہو سکا",Toast.LENGTH_SHORT).show();}}
    private void importBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,IMPORT_REQ);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null)return;try{Uri u=data.getData();if(request==EXPORT_REQ){JSONArray a=new JSONArray();for(Word w:words)a.put(w.json());try(OutputStream os=getContentResolver().openOutputStream(u)){os.write(a.toString(2).getBytes(StandardCharsets.UTF_8));}Toast.makeText(this,"بیک اَپ محفوظ ہو گیا",Toast.LENGTH_LONG).show();}else if(request==IMPORT_REQ){StringBuilder s=new StringBuilder();try(InputStream is=getContentResolver().openInputStream(u);BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)s.append(line);}JSONArray a=new JSONArray(s.toString());words.clear();for(int n=0;n<a.length();n++){JSONObject o=a.getJSONObject(n);words.add(new Word(o.optString("word"),o.optString("meaning"),o.optString("root"),o.optString("bab"),o.optString("note")));}save();showHome();Toast.makeText(this,"بیک اَپ بحال ہو گیا",Toast.LENGTH_LONG).show();}}catch(Exception e){Toast.makeText(this,"فائل درست نہیں یا پڑھنے میں مسئلہ ہے",Toast.LENGTH_LONG).show();}}
}
